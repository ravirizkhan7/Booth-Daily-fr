import { stocks, stock_histories, purchases, recipes } from '../data/dummy';
import { Stock, StockHistory, Purchase } from '../types';

export const stockService = {
  async getStocks(): Promise<Stock[]> {
    return Promise.resolve([...stocks]);
  },

  async getStockHistories(): Promise<StockHistory[]> {
    return Promise.resolve([...stock_histories]);
  },

  async getPurchases(): Promise<Purchase[]> {
    return Promise.resolve([...purchases]);
  },

  // Stock Ingredient CRUD
  async createStock(stockData: Omit<Stock, 'id'>): Promise<Stock> {
    const newStock: Stock = {
      ...stockData,
      id: `stk-${Date.now()}`
    };
    stocks.unshift(newStock);

    // Initial stock history
    if (newStock.current_amount > 0) {
      stock_histories.unshift({
        id: `sth-${Date.now()}`,
        stock_id: newStock.id,
        stock_name: newStock.name,
        change_amount: newStock.current_amount,
        unit: newStock.unit,
        type: 'in',
        reference: 'Stok Awal Bahan Baku',
        created_at: new Date().toISOString()
      });
    }

    return Promise.resolve(newStock);
  },

  async updateStock(id: string, stockData: Partial<Stock>): Promise<Stock> {
    const index = stocks.findIndex(s => s.id === id);
    if (index !== -1) {
      stocks[index] = { ...stocks[index], ...stockData };
      return Promise.resolve(stocks[index]);
    }
    throw new Error('Bahan baku tidak ditemukan');
  },

  async deleteStock(id: string): Promise<boolean> {
    const index = stocks.findIndex(s => s.id === id);
    if (index !== -1) {
      stocks.splice(index, 1);
      return Promise.resolve(true);
    }
    return Promise.resolve(false);
  },

  // Stock Adjustment
  async adjustStock(
    stockId: string,
    changeAmount: number,
    reason: string,
    userName: string = 'Owner'
  ): Promise<Stock> {
    const stock = stocks.find(s => s.id === stockId);
    if (!stock) throw new Error('Bahan baku tidak ditemukan');

    stock.current_amount = Math.max(0, stock.current_amount + changeAmount);

    stock_histories.unshift({
      id: `sth-${Date.now()}`,
      stock_id: stock.id,
      stock_name: stock.name,
      change_amount: changeAmount,
      unit: stock.unit,
      type: 'penyesuaian',
      reference: reason,
      user_name: userName,
      final_amount: stock.current_amount,
      created_at: new Date().toISOString()
    });

    return Promise.resolve(stock);
  },

  // Automatic deduction on recipe execution
  async deductStockByRecipe(productId: string, qty: number, orderRef: string): Promise<void> {
    const recipe = recipes.find(r => r.product_id === productId);
    if (recipe && recipe.ingredients) {
      for (const ing of recipe.ingredients) {
        const stock = stocks.find(s => s.id === ing.stock_id);
        if (stock) {
          const totalDeduct = ing.amount * qty;
          stock.current_amount = Math.max(0, stock.current_amount - totalDeduct);
          stock_histories.unshift({
            id: `sth-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            stock_id: stock.id,
            stock_name: stock.name,
            change_amount: -totalDeduct,
            unit: ing.unit || stock.unit,
            type: 'penjualan',
            reference: `Order #${orderRef}`,
            user_name: 'Kasir',
            final_amount: stock.current_amount,
            created_at: new Date().toISOString()
          });
        }
      }
    }
    return Promise.resolve();
  },

  // Purchase Management CRUD
  async createPurchase(purchaseData: Omit<Purchase, 'id'>): Promise<Purchase> {
    const newPurchase: Purchase = {
      ...purchaseData,
      id: `pur-${Date.now()}`
    };
    purchases.unshift(newPurchase);

    // Auto-increase stocks
    for (const item of newPurchase.items) {
      const stock = stocks.find(s => s.id === item.stock_id);
      if (stock) {
        stock.current_amount += item.qty;
        stock_histories.unshift({
          id: `sth-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          stock_id: stock.id,
          stock_name: stock.name,
          change_amount: item.qty,
          unit: stock.unit,
          type: 'pembelian',
          reference: `Pembelian #${newPurchase.purchase_number} (${newPurchase.supplier})`,
          user_name: 'Owner',
          final_amount: stock.current_amount,
          created_at: new Date().toISOString()
        });
      }
    }

    return Promise.resolve(newPurchase);
  },

  async updatePurchase(id: string, purchaseData: Partial<Purchase>): Promise<Purchase> {
    const index = purchases.findIndex(p => p.id === id);
    if (index === -1) throw new Error('Pembelian tidak ditemukan');

    const oldPurchase = purchases[index];

    // Revert old purchase stock amounts
    for (const oldItem of oldPurchase.items) {
      const stock = stocks.find(s => s.id === oldItem.stock_id);
      if (stock) {
        stock.current_amount = Math.max(0, stock.current_amount - oldItem.qty);
      }
    }

    const updatedPurchase: Purchase = {
      ...oldPurchase,
      ...purchaseData
    };
    purchases[index] = updatedPurchase;

    // Apply new purchase stock amounts
    for (const newItem of updatedPurchase.items) {
      const stock = stocks.find(s => s.id === newItem.stock_id);
      if (stock) {
        stock.current_amount += newItem.qty;
        stock_histories.unshift({
          id: `sth-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          stock_id: stock.id,
          stock_name: stock.name,
          change_amount: newItem.qty,
          unit: stock.unit,
          type: 'in',
          reference: `Revisi Pembelian #${updatedPurchase.purchase_number}`,
          created_at: new Date().toISOString()
        });
      }
    }

    return Promise.resolve(updatedPurchase);
  },

  async deletePurchase(id: string): Promise<boolean> {
    const index = purchases.findIndex(p => p.id === id);
    if (index !== -1) {
      const oldPurchase = purchases[index];
      // Revert stock amounts
      for (const item of oldPurchase.items) {
        const stock = stocks.find(s => s.id === item.stock_id);
        if (stock) {
          stock.current_amount = Math.max(0, stock.current_amount - item.qty);
          stock_histories.unshift({
            id: `sth-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            stock_id: stock.id,
            stock_name: stock.name,
            change_amount: -item.qty,
            unit: stock.unit,
            type: 'out',
            reference: `Pembatalan Pembelian #${oldPurchase.purchase_number}`,
            created_at: new Date().toISOString()
          });
        }
      }
      purchases.splice(index, 1);
      return Promise.resolve(true);
    }
    return Promise.resolve(false);
  }
};
