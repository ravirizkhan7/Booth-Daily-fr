import { users } from '../data/dummy';
import { User } from '../types';

export const userService = {
  async getUsers(): Promise<User[]> {
    return Promise.resolve([...users]);
  },

  async verifyPin(pin: string): Promise<User | null> {
    const matchedUser = users.find(u => u.pin === pin && u.is_active);
    return Promise.resolve(matchedUser || null);
  },

  async createUser(userData: Omit<User, 'id'>): Promise<User> {
    const newUser: User = {
      ...userData,
      id: `usr-${Date.now()}`
    };
    users.push(newUser);
    return Promise.resolve(newUser);
  },

  async updateUser(id: string, userData: Partial<User>): Promise<User> {
    const idx = users.findIndex(u => u.id === id);
    if (idx !== -1) {
      users[idx] = { ...users[idx], ...userData };
      return Promise.resolve(users[idx]);
    }
    throw new Error('User not found');
  },

  async deleteUser(id: string): Promise<boolean> {
    const idx = users.findIndex(u => u.id === id);
    if (idx !== -1) {
      users.splice(idx, 1);
      return Promise.resolve(true);
    }
    return Promise.resolve(false);
  }
};
