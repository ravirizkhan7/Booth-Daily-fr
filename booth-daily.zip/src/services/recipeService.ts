import { recipes } from '../data/dummy';
import { Recipe } from '../types';

export const recipeService = {
  async getRecipes(): Promise<Recipe[]> {
    return Promise.resolve([...recipes]);
  },

  async getRecipeByProductId(productId: string): Promise<Recipe | undefined> {
    return Promise.resolve(recipes.find(r => r.product_id === productId));
  },

  async saveRecipe(recipeData: Omit<Recipe, 'id'>): Promise<Recipe> {
    const existingIndex = recipes.findIndex(r => r.product_id === recipeData.product_id);
    if (existingIndex !== -1) {
      recipes[existingIndex] = {
        ...recipes[existingIndex],
        ...recipeData
      };
      return Promise.resolve(recipes[existingIndex]);
    } else {
      const newRecipe: Recipe = {
        ...recipeData,
        id: `rcp-${Date.now()}`
      };
      recipes.unshift(newRecipe);
      return Promise.resolve(newRecipe);
    }
  },

  async deleteRecipe(id: string): Promise<boolean> {
    const index = recipes.findIndex(r => r.id === id);
    if (index !== -1) {
      recipes.splice(index, 1);
      return Promise.resolve(true);
    }
    return Promise.resolve(false);
  }
};
