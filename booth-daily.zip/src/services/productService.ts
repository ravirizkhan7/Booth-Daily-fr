import { products, categories } from '../data/dummy';
import { Product, Category } from '../types';

export const productService = {
  async getProducts(): Promise<Product[]> {
    return Promise.resolve([...products]);
  },

  async getCategories(): Promise<Category[]> {
    return Promise.resolve([...categories]);
  },

  async getProductById(id: string): Promise<Product | undefined> {
    return Promise.resolve(products.find(p => p.id === id));
  },

  async createProduct(productData: Omit<Product, 'id'>): Promise<Product> {
    const newProduct: Product = {
      ...productData,
      id: `prd-${Date.now()}`
    };
    products.unshift(newProduct);
    return Promise.resolve(newProduct);
  },

  async updateProduct(id: string, productData: Partial<Product>): Promise<Product> {
    const index = products.findIndex(p => p.id === id);
    if (index !== -1) {
      products[index] = { ...products[index], ...productData };
      return Promise.resolve(products[index]);
    }
    throw new Error('Product not found');
  },

  async deleteProduct(id: string): Promise<boolean> {
    const index = products.findIndex(p => p.id === id);
    if (index !== -1) {
      products.splice(index, 1);
      return Promise.resolve(true);
    }
    return Promise.resolve(false);
  },

  // Category CRUD
  async createCategory(categoryData: Omit<Category, 'id' | 'slug'>): Promise<Category> {
    const newCat: Category = {
      ...categoryData,
      id: `cat-${Date.now()}`,
      slug: categoryData.name.toLowerCase().replace(/\s+/g, '-')
    };
    categories.push(newCat);
    return Promise.resolve(newCat);
  },

  async updateCategory(id: string, categoryData: Partial<Category>): Promise<Category> {
    const index = categories.findIndex(c => c.id === id);
    if (index !== -1) {
      const updatedSlug = categoryData.name ? categoryData.name.toLowerCase().replace(/\s+/g, '-') : categories[index].slug;
      categories[index] = {
        ...categories[index],
        ...categoryData,
        slug: updatedSlug
      };
      return Promise.resolve(categories[index]);
    }
    throw new Error('Category not found');
  },

  async deleteCategory(id: string): Promise<boolean> {
    const index = categories.findIndex(c => c.id === id);
    if (index !== -1) {
      categories.splice(index, 1);
      return Promise.resolve(true);
    }
    return Promise.resolve(false);
  }
};
