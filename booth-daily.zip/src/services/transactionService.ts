import { orderService } from './orderService';
import { stockService } from './stockService';
import { Order, PaymentMethod, OrderType, OrderItem, User } from '../types';

export interface CreateTransactionPayload {
  order_type: OrderType;
  items: Omit<OrderItem, 'id' | 'subtotal'>[];
  payment_method: PaymentMethod;
  amount_paid: number;
  customer_name?: string;
  user: User; // Authenticated by PIN
}

export const transactionService = {
  async processTransaction(payload: CreateTransactionPayload): Promise<Order> {
    const formattedItems: OrderItem[] = payload.items.map((item, index) => ({
      ...item,
      id: `ori-${Date.now()}-${index}`,
      subtotal: item.price * item.qty
    }));

    const subtotal = formattedItems.reduce((acc, item) => acc + item.subtotal, 0);
    const tax = 0;
    const discount = 0;
    const total_amount = subtotal + tax - discount;
    const change = Math.max(0, payload.amount_paid - total_amount);

    const newOrder = await orderService.createOrder({
      order_type: payload.order_type,
      created_by_user_id: payload.user.id,
      created_by_name: payload.user.name,
      created_by_role: payload.user.role,
      subtotal,
      tax,
      discount,
      total_amount,
      customer_name: payload.customer_name || (payload.order_type === 'dine_in' ? 'Dine In' : 'Take Away'),
      payment: {
        id: `pay-${Date.now()}`,
        order_id: '',
        method: payload.payment_method,
        amount_paid: payload.amount_paid,
        change,
        status: 'completed'
      },
      items: formattedItems
    });

    newOrder.payment.order_id = newOrder.id;

    // Deduct stock per ordered product
    for (const item of formattedItems) {
      await stockService.deductStockByRecipe(item.product_id, item.qty, newOrder.order_number);
    }

    return newOrder;
  }
};
