import { orders } from '../data/dummy';
import { Order } from '../types';

export const orderService = {
  async getOrders(): Promise<Order[]> {
    return Promise.resolve([...orders]);
  },

  async getOrderById(id: string): Promise<Order | undefined> {
    return Promise.resolve(orders.find(o => o.id === id));
  },

  async createOrder(orderData: Omit<Order, 'id' | 'order_number' | 'created_at'>): Promise<Order> {
    const todayStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const count = orders.length + 1;
    const orderNum = `BD-${todayStr}-${String(count).padStart(3, '0')}`;

    const newOrder: Order = {
      ...orderData,
      id: `ord-${Date.now()}`,
      order_number: orderNum,
      created_at: new Date().toISOString()
    };

    orders.unshift(newOrder);
    return Promise.resolve(newOrder);
  }
};
