import React, { useRef, useState } from 'react';
import { UploadCloud, X, Image as ImageIcon, AlertCircle } from 'lucide-react';

interface ImageUploadProps {
  value?: string;
  onChange: (base64Url: string) => void;
  label?: string;
  error?: string;
  maxSizeMB?: number;
}

export const ImageUpload: React.FC<ImageUploadProps> = ({
  value,
  onChange,
  label = 'Foto Produk',
  error,
  maxSizeMB = 5
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [localError, setLocalError] = useState<string>('');

  const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];

  const handleFileProcess = (file: File) => {
    setLocalError('');

    if (!allowedTypes.includes(file.type)) {
      setLocalError('Format file tidak didukung. Gunakan JPG, JPEG, PNG, atau WEBP.');
      return;
    }

    if (file.size > maxSizeMB * 1024 * 1024) {
      setLocalError(`Ukuran file melebihi batas maksimum ${maxSizeMB}MB.`);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        onChange(reader.result);
      }
    };
    reader.onerror = () => {
      setLocalError('Gagal membaca file gambar.');
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileProcess(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileProcess(file);
    }
  };

  const handleRemove = (e: React.MouseEvent) => {
    e.stopPropagation();
    onChange('');
    setLocalError('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-1.5">
      {label && (
        <label className="block text-xs font-bold text-stone-700 dark:text-stone-300">
          {label}
        </label>
      )}

      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/jpeg,image/png,image/webp,image/jpg"
        className="hidden"
      />

      {value ? (
        <div className="relative group rounded-2xl overflow-hidden border border-stone-200 dark:border-stone-800 bg-stone-100 dark:bg-[#151312] aspect-video flex items-center justify-center">
          <img
            src={value}
            alt="Preview"
            className="w-full h-full object-cover transition-transform duration-200 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 bg-white/90 text-stone-900 rounded-xl text-xs font-bold shadow hover:bg-white transition-colors"
            >
              Ubah Gambar
            </button>
            <button
              type="button"
              onClick={handleRemove}
              className="p-1.5 bg-rose-600 text-white rounded-xl text-xs font-bold shadow hover:bg-rose-700 transition-colors"
              title="Hapus Gambar"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        <div
          onClick={() => fileInputRef.current?.click()}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all duration-150 flex flex-col items-center justify-center gap-2 ${
            isDragging
              ? 'border-[#3B2A1F] dark:border-[#D4A373] bg-[#3B2A1F]/5 dark:bg-[#D4A373]/5'
              : 'border-stone-300 dark:border-stone-700 hover:border-[#3B2A1F] dark:hover:border-[#D4A373] bg-stone-50/50 dark:bg-[#151312]/50'
          }`}
        >
          <div className="w-10 h-10 rounded-2xl bg-stone-100 dark:bg-stone-800 flex items-center justify-center text-stone-500">
            <UploadCloud className="w-5 h-5 text-[#3B2A1F] dark:text-[#D4A373]" />
          </div>
          <div>
            <p className="text-xs font-bold text-stone-800 dark:text-stone-200">
              Klik atau seret file gambar ke sini
            </p>
            <p className="text-[10px] text-stone-400 font-medium mt-0.5">
              Format: JPG, JPEG, PNG, WEBP (Maksimal {maxSizeMB}MB)
            </p>
          </div>
        </div>
      )}

      {(error || localError) && (
        <div className="flex items-center gap-1.5 text-rose-600 text-xs font-bold pt-1">
          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
          <span>{error || localError}</span>
        </div>
      )}
    </div>
  );
};
